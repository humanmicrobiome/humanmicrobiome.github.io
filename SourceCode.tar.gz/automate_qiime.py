#!/usr/bin/env python -u etc
import os
import sys
import subprocess

all_sample_ids = ""
all_files = ""

newf = open("logs.txt","w+")
script_path = os.getcwd()
usearch_path = os.getcwd() #"/home/atharva/Data"

#set variables from args
mapping_file = sys.argv[1]
input_dir = sys.argv[2]
sample_name = sys.argv[3]
barcode = sys.argv[4]
output_dir = sys.argv[5]
otu_method = sys.argv[6]

newf.write(mapping_file)
newf.write(input_dir)
newf.write(sample_name)
newf.write(output_dir)

#print "input dir " + input_dir
#print "output_dir" + output_dir

#open mapping file
f = open(mapping_file,"r")
print "Reading from  mapping file : " + mapping_file
sys.stdout.flush()
header = f.readline().split("\t")
#print header
sample_id_position = header.index("#SampleID")
group_position = header.index("Grouping")

subjects = set()
count = 0
for line in f:
	splitted_line = line.split("\t")
	subjects.add(splitted_line[group_position])
	sampleId = splitted_line[sample_id_position]
	#print sampleId + "\n"
	all_sample_ids = all_sample_ids + sampleId + ","
	file1 = sample_name + "-" + barcode + sampleId[4:] + "_S" + sampleId[4:] + "_L001_R1_001.fastq.gz"
	file2 = sample_name + "-" + barcode + sampleId[4:] + "_S" + sampleId[4:] + "_L001_R2_001.fastq.gz"
	#print file1 +  "   " + file2
	subprocess.check_call("join_paired_ends.py -f " +  input_dir + "/" + file1 +" -r "+ input_dir + "/" + file2 + " -o " + output_dir,  shell=True)
	dst = "joined_"+  sampleId[4:] +".fastq"
	os.rename(output_dir + "/fastqjoin.join.fastq", output_dir + "/"+ dst)
	all_files = all_files + dst + ","
	newf.write(dst)
	count+=1


#newf.write(subjects)
#newf.write(all_files)
#newf.write(all_sample_ids)

print "Joined R1 and R2 files for all samples can be found in " + output_dir
filenames = open("filenames","w+")
samples = open("samples.txt", "w+")
filenames.write(all_files[:-1])
samples.write(all_sample_ids[:-1])
f.close()
all_sample_ids = all_sample_ids[:-1]
#print all_sample_ids
all_files = all_files[:-1]
os.chdir(output_dir)
pwd = os.getcwd()

print "Combining all fastq files into a single seqs.fna file."
subprocess.check_call("split_libraries_fastq.py -i " + all_files + " -o " + pwd + "/automated_sl_out/ -m " + mapping_file  + " --barcode_type not-barcoded   --sample_ids " + all_sample_ids, shell=True)

print "Created seqs.fna file in " + pwd + "/automated_sl_out folder."

if otu_method == "0":
	print "Creating OTU tables using QIIME:De Novo Method"
	sys.stdout.flush()
	try:	
		subprocess.check_call("pick_de_novo_otus.py -i " + pwd + "/automated_sl_out/seqs.fna -o " + pwd + "/de_novo_uclust_otus/" , shell=True)
		subprocess.check_call("biom summarize-table -i " + pwd + "/de_novo_uclust_otus/otu_table.biom -o " + pwd + "/de_novo_uclust_otus/biom_summary.txt", shell=True)
		subprocess.check_call("summarize_taxa_through_plots.py -i " + pwd + "/de_novo_uclust_otus/otu_table.biom -o " + pwd + "/de_novo_uclust_otus/taxa_summary -m " + mapping_file + " -s", shell=True)
		print "Summary of taxonomy can be found in " + pwd + "/de_novo_uclust_otus/taxa_summary"
		sys.stdout.flush()
		if count > 4:
			print "Generating Beta diversity pcoa plots."
			sys.stdout.flush()
			subprocess.check_call("beta_diversity_through_plots.py -i " + pwd + "/de_novo_uclust_otus/otu_table.biom -o " + pwd + "/de_novo_uclust_otus/Beta_diversity/ -t " + pwd + "/de_novo_uclust_otus/rep_set.tre -m " + mapping_file, shell=True)
			print "Generating 2D plots for Beta diversity."
			sys.stdout.flush()
			subprocess.check_call("make_2d_plots.py -i " + pwd + "/de_novo_uclust_otus/Beta_diversity/unweighted_unifrac_pc.txt -o " + pwd + "/de_novo_uclust_otus/Beta_diversity/bdiv_2d_plot -m " + mapping_file, shell = True)
			print "Generated 2D plots for beta diversity in " + pwd + "/de_novo_uclust_otus/Beta_diversity/bdiv_2d_plot"
			print "Calculating Alpha diversity."
			sys.stdout.flush()
			subprocess.check_call("multiple_rarefactions.py -i " + pwd + "/de_novo_uclust_otus/otu_table.biom -m 10 -x 140 -s 10 -n 2 -o " + pwd + "de_novo_uclust_otus/Alpha_diversity/rarefied_otu_tables/", shell=True)
			subprocess.check_call("alpha_diversity.py -i " + pwd + "/de_novo_uclust_otus/Alpha_diversity/rarefied_otu_tables/ -m chao1,PD_whole_tree -o "+ pwd + "de_novo_uclust_otus/Alpha_diversity/adiv_chao1_pd/ -t "+ pwd + "/de_novo_uclust_otus/rep_set.tre", shell=True)
			subprocess.check_call("collate_alpha.py -i " + pwd + "de_novo_uclust_otus/Alpha_diversity/adiv_chao1_pd/ -o " + pwd + "de_novo_uclust_otus/Alpha_div/collated_alpha/", shell=True)
			subprocess.check_call("compare_alpha_diversity.py -i " + pwd +"/de_novo_uclust_otus/Alpha_diversity/collated_alpha/PD_whole_tree.txt -m " + mapping_file + " -c Grouping -o " + pwd + "/de_novo_uclust_otus/Alpha_diversity/comparing_alpha_grouping", shell=True)
	except OSError as e:
		print("Execution failed:", e, sys.stderr)
		sys.stdout.flush()	
elif otu_method == "1":
	print "Creating OTU tables using QIIME:Open reference clustering. GreenGenes will be used as reference database."
	sys.stdout.flush()
	try:
		subprocess.check_call("pick_open_reference_otus.py -i " + pwd + "/automated_sl_out/seqs.fna -o " + pwd + "/open_ref_ucrc97/ -r "+ script_path + "/gg_13_5_otus/rep_set/97_otus.fasta", shell=True)
		print "Summarizing the biom tables." 
		sys.stdout.flush()
		subprocess.check_call("biom summarize-table -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -o" + pwd + "/open_ref_ucrc97/biom_summary.txt", shell=True)
		subprocess.check_call("summarize_taxa_through_plots.py -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -o " + pwd + "/open_ref_ucrc97/taxa_summary -m " + mapping_file + " -s", shell=True)
		print "Summary of taxonomy can be found in " + pwd + "/open_ref_ucrc97/taxa_summary"
		sys.stdout.flush()
		if count > 4:
			print "Generating Beta diversity pcoa plots."
			sys.stdout.flush()
			subprocess.check_call("beta_diversity_through_plots.py -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -o " + pwd + "/open_ref_ucrc97/Beta_diversity/ -t " + pwd + "/open_ref_ucrc97/rep_set.tre -m " + mapping_file, shell=True)
			print "Generating 2D plots for Beta diversity."
			sys.stdout.flush()
			subprocess.check_call("make_2d_plots.py -i " + pwd + "/open_ref_ucrc97/Beta_diversity/unweighted_unifrac_pc.txt -o " + pwd + "/open_ref_ucrc97/Beta_diversity/bdiv_2d_plot -m " + mapping_file, shell = True)
			print "Generated 2D plots for beta diversity in " + pwd + "/open_ref_ucrc97/Beta_diversity/bdiv_2d_plot"
			print "Calculating Alpha diversity."
			sys.stdout.flush()
			subprocess.check_call("multiple_rarefactions.py -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -m 10 -x 140 -s 10 -n 2 -o " + pwd + "open_ref_ucrc97/Alpha_diversity/rarefied_otu_tables/", shell=True)
			subprocess.check_call("alpha_diversity.py -i " + pwd + "/open_ref_ucrc97/Alpha_diversity/rarefied_otu_tables/ -m chao1,PD_whole_tree -o "+ pwd + "open_ref_ucrc97/Alpha_diversity/adiv_chao1_pd/ -t "+ pwd + "/open_ref_ucrc97/rep_set.tre", shell=True)
			subprocess.check_call("collate_alpha.py -i " + pwd + "open_ref_ucrc97/Alpha_diversity/adiv_chao1_pd/ -o " + pwd + "open_ref_ucrc97/Alpha_div/collated_alpha/", shell=True)
			subprocess.check_call("compare_alpha_diversity.py -i " + pwd +"/open_ref_ucrc97/Alpha_diversity/collated_alpha/PD_whole_tree.txt -m " + mapping_file + " -c Grouping -o " + pwd + "/open_ref_ucrc97/Alpha_diversity/comparing_alpha_grouping", shell=True)
	except OSError as e:
		print("Execution failed:", e, sys.stderr)
		sys.stdout.flush()

elif otu_method == "2":
	print "Creating OTU tables using QIIME: Closed reference clustering. GreenGenes will be used as reference database."
	subprocess.check_call("pick_closed_reference_otus.py -i " + output_dir + "/automated_sl_out/seqs.fna -o " + output_dir + "/closed_ref_ucrc97/ -r "+ script_path + "/gg_13_5_otus/rep_set/97_otus.fasta -t " + script_path + "/gg_13_5_otus/taxonomy/97_otu_taxonomy.txt", shell=True)
	while subjects:
		subject = subjects.pop()
		print subject
		os.mkdir(output_dir + "/closed_ref_ucrc97/" + subject)
		subprocess.check_call("filter_samples_from_otu_table.py -i " + output_dir + "/closed_ref_ucrc97/otu_table.biom -o " + output_dir + "/closed_ref_ucrc97/" + subject + "/otu_table_"+ subject +"_only.biom -m " + mapping_file +" -s 'Grouping:" + subject + "'", shell=True)
		subprocess.check_call("biom summarize-table -i " + output_dir + "/closed_ref_ucrc97/" + subject + "/otu_table_"+ subject +"_only.biom  -o " + output_dir + "/closed_ref_ucrc97/" + subject + "/biom_summary.txt", shell=True)
		subprocess.check_call("summarize_taxa_through_plots.py -i " + output_dir + "/closed_ref_ucrc97/" + subject + "/otu_table_"+ subject +"_only.biom -o " + output_dir + "/closed_ref_ucrc97/" + subject + "/taxa_summary -m " + mapping_file, shell=True)
		print "Summary of taxonomy can be found in subject specific folders under " + output_dir + "/closed_ref_ucrc97"

elif otu_method == "3":
	print "Creating OTU tables using UPARSE."
	os.mkdir(output_dir + "/uparse_output")
	f = open(mapping_file,"r")
	header = f.readline().split("\t")
	#print os.getcwd()
	for line in f:
		splitted_line = line.split("\t")
		sampleId = splitted_line[sample_id_position]
		#print sampleId
		subprocess.check_call(usearch_path + "/usearch --fastq_filter  " + output_dir + "/joined_"  + sampleId[4:] + ".fastq --fastaout " + output_dir + "/uparse_output/joined_" + sampleId[4:] + ".filtered.fa --fastq_maxee 0.5", shell=True)
	
	os.chdir(output_dir + "/uparse_output")
	subprocess.check_call("cat *.filtered.fa > single_filtered.fa", shell=True)
	subprocess.check_call(usearch_path + "/usearch -derep_fulllength " + output_dir + "/uparse_output/single_filtered.fa -fastaout "+ output_dir + "/uparse_output/derep.fa -sizeout", shell=True)
	subprocess.check_call(usearch_path + "/usearch -sortbysize " +  output_dir  + "/uparse_output/derep.fa -fastaout " + output_dir + "/uparse_output/sorted.min2.fa -minsize 2", shell=True)
	subprocess.check_call(usearch_path + "/usearch -cluster_otus " + output_dir +"/uparse_output/sorted.min2.fa -otus "+ output_dir + "/uparse_output/otu_reps.init.up -uparseout " + output_dir + "/uparse_output/out.up -relabel OTU", shell=True)
	subprocess.check_call(usearch_path + "/usearch -usearch_global "+ output_dir  + "/uparse_output/single_filtered.fa -db " + output_dir  + "/uparse_output/otu_reps.init.up -strand plus -id 0.97 -uc " + output_dir + "/uparse_output/otu_map.uc", shell=True)

	#install RDP and set RDP path before running this command
	#subprocess.check_call("assign_taxonomy.py -i " + output_dir + "/uparse_output/otu_reps.init.up -m rdp", shell=True)

else:
	print "Please choose the valid method for OTU clustering."
	print "Exiting the process due to bad input."


print "Done."
filenames.close()
samples.close()
f.close()
newf.close()

#if __name__ == '__main__':
#   run_qiime()


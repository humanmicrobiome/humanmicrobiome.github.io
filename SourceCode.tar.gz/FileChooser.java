package windowBuilder.views;

import java.awt.EventQueue;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeoutException;

import javax.swing.JLabel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

import org.zeroturnaround.exec.InvalidExitValueException;
import org.zeroturnaround.exec.ProcessExecutor;
import org.zeroturnaround.exec.stream.LogOutputStream;

import javax.swing.border.BevelBorder;
import java.awt.Component;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


 class ButtonEnablement implements DocumentListener {

    private ButtonModel buttonModel;
    private List<Document> documents = new ArrayList<Document>();

    public ButtonEnablement(ButtonModel buttonModel) {
        this.buttonModel = buttonModel;
    }

    public void addDocument(Document document) {
        document.addDocumentListener(this);
        this.documents.add(document);
        documentChanged();
    }

    public void documentChanged() {
        boolean buttonEnabled = false;
        for (Document document : documents) {
            if (document.getLength() > 0) {
                buttonEnabled = true;
            }
            else
            {
            	buttonEnabled = false;
            	break;
            }
        }
        buttonModel.setEnabled(buttonEnabled);
    }

    @Override
    public void insertUpdate(DocumentEvent e) {
        documentChanged();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        documentChanged();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        documentChanged();
    }
}



@SuppressWarnings("serial")
public class FileChooser extends JFrame {

	private JPanel contentPane;
	private JTextField txtSource;
	private JLabel lblSource;
	private JLabel lblOutput;
	private JTextField txtOutput;
	private JButton outputBrowse;
	private JLabel lblEnterSampleName;
	private JTextField txtSample;
	private JLabel lblEnterBracodeSequence;
	private JTextField txtBarcode;
	private JLabel lblMap;
	private JTextField txtMap;
	private JButton mapBrowse;
	private JButton createOTU;
	private JTextArea txtMsgs;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FileChooser frame = new FileChooser();
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FileChooser() {
		setTitle("OTUGenerator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1150, 620);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		JScrollPane jsp = new JScrollPane(contentPane);

		setContentPane(jsp);




		txtSource = new JTextField();
		txtSource.setColumns(10);

		JButton sourceBrowse = new JButton("Browse");
		sourceBrowse.setAlignmentX(Component.CENTER_ALIGNMENT);
		sourceBrowse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				JFileChooser jfc = new JFileChooser();
				jfc.setCurrentDirectory(new java.io.File("C:/"));
				jfc.setDialogTitle("Choose source folder");
				jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				if(jfc.showOpenDialog(sourceBrowse) == JFileChooser.APPROVE_OPTION){
					txtSource.setText(jfc.getSelectedFile().getAbsolutePath());
				}


			}
		});

		lblSource = new JLabel("Enter Source folder:");

		lblOutput = new JLabel("Enter output folder:");

		txtOutput = new JTextField();
		txtOutput.setColumns(10);

		outputBrowse = new JButton("Browse");
		outputBrowse.setAlignmentX(Component.CENTER_ALIGNMENT);
		outputBrowse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				JFileChooser jfc = new JFileChooser();
				jfc.setCurrentDirectory(new java.io.File("C:/"));
				jfc.setDialogTitle("Choose output folder");
				jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				if(jfc.showOpenDialog(sourceBrowse) == JFileChooser.APPROVE_OPTION){
					txtOutput.setText(jfc.getSelectedFile().getAbsolutePath());
				}


			}
		});

		lblEnterSampleName = new JLabel("Enter Sample Name:");

		txtSample = new JTextField();
		txtSample.setColumns(10);

		lblEnterBracodeSequence = new JLabel("Enter Barcode Sequence prefix:");

		txtBarcode = new JTextField();
		txtBarcode.setColumns(10);

		lblMap = new JLabel("Enter Mapping file:");

		txtMap = new JTextField();
		txtMap.setColumns(10);

		mapBrowse = new JButton("Browse");
		mapBrowse.setAlignmentX(Component.CENTER_ALIGNMENT);
		mapBrowse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				JFileChooser jfc = new JFileChooser();
				jfc.setCurrentDirectory(new java.io.File("C:/"));
				jfc.setDialogTitle("Choose mapping file");


				if(jfc.showOpenDialog(sourceBrowse) == JFileChooser.APPROVE_OPTION){
					txtMap.setText(jfc.getSelectedFile().getAbsolutePath());
				}

			}
		});

		createOTU = new JButton("Create OTUs");

		ButtonModel model = createOTU.getModel();
		Document doc1 = txtMap.getDocument();
		Document doc2 = txtSource.getDocument();
		Document doc3 = txtSample.getDocument();
		Document doc4 = txtBarcode.getDocument();
		Document doc5 = txtOutput.getDocument();

		ButtonEnablement buttonE = new ButtonEnablement(model);
		buttonE.addDocument(doc1);
		buttonE.addDocument(doc2);
		buttonE.addDocument(doc3);
		buttonE.addDocument(doc4);
		buttonE.addDocument(doc5);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Messages", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));



		txtMsgs = new JTextArea();
		txtMsgs.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		txtMsgs.setEditable(false);

		JScrollPane scrollMsgs = new JScrollPane(txtMsgs);
		scrollMsgs.setAutoscrolls(true);

		JComboBox<String> chooseOTU = new JComboBox<String>();
		chooseOTU.setModel(new DefaultComboBoxModel<String>(new String[] {"DeNovo", "Open Reference", "Closed Reference", "UParse"}));

		createOTU.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {


				txtMsgs.setText(null);

					try{

					List<String> cmd = new ArrayList<String>();

					cmd.addAll(Arrays.asList("python","automate_qiime.py"));

					cmd.addAll(Arrays.asList(txtMap.getText()));
					cmd.addAll(Arrays.asList(txtSource.getText()));
					cmd.addAll(Arrays.asList(txtSample.getText()));
					cmd.addAll(Arrays.asList(txtBarcode.getText()));
					cmd.addAll(Arrays.asList(txtOutput.getText()));
					cmd.addAll(Arrays.asList(String.valueOf(chooseOTU.getSelectedIndex())));

					new ProcessExecutor().command(cmd)
							.redirectOutput(new LogOutputStream(){
								@Override
								protected void processLine(String line){

									txtMsgs.append(line+"\n");
									txtMsgs.update(txtMsgs.getGraphics());

									txtMsgs.setCaretPosition(txtMsgs.getDocument().getLength());

								}
							})
							.execute();





					}catch(IOException e1){
						e1.printStackTrace();
					}catch(TimeoutException e2){
						e2.printStackTrace();
					} catch (InvalidExitValueException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

			}
		});



		JLabel lblChooseOtuClustering = new JLabel("Choose OTU Clustering method:");







		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(24)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(createOTU)
							.addGap(149))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblMap)
								.addComponent(lblEnterSampleName)
								.addComponent(lblOutput)
								.addComponent(lblSource)
								.addComponent(lblEnterBracodeSequence)
								.addComponent(lblChooseOtuClustering))
							.addGap(80)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(chooseOTU, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(txtBarcode)
								.addComponent(txtSample)
								.addComponent(txtOutput)
								.addComponent(txtSource)
								.addComponent(txtMap, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE))))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(sourceBrowse, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
							.addComponent(mapBrowse, GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
							.addComponent(outputBrowse, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
					.addGap(18)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(75)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblMap)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(txtMap, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addComponent(mapBrowse, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(txtSource, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblSource)
								.addComponent(sourceBrowse, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
							.addGap(14)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(txtOutput, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblOutput)
								.addComponent(outputBrowse, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
							.addGap(22)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(txtSample, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblEnterSampleName))
							.addGap(29)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(txtBarcode, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblEnterBracodeSequence))
							.addGap(29)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblChooseOtuClustering)
								.addComponent(chooseOTU, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 188, Short.MAX_VALUE)
							.addComponent(createOTU))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(51)
							.addComponent(panel, GroupLayout.DEFAULT_SIZE, 470, Short.MAX_VALUE)))
					.addGap(49))
		);


		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollMsgs, GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollMsgs, GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
	}
}

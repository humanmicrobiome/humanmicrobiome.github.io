#!/usr/bin/env python -u etc
import os
import sys
import subprocess
# a simple class with a write method
'''
class WritableObject:
    def __init__(self):
        self.content = []
    def write(self, string):
        self.content.append(string)

bar = WritableObject()                   # another writable object
print >>bar, "one, two, three, four"     # some (redirected) writing
print >>bar, "little hat made of paper"
print "bar's content:", bar.content     

'''
all_sample_ids = ""
all_files = ""

newf = open("logs.txt","w+")
script_path = os.getcwd()

#set variables from args
mapping_file = sys.argv[1]
input_dir = sys.argv[2]
sample_name = sys.argv[3]
barcode = sys.argv[4]
output_dir = sys.argv[5]
otu_method = sys.argv[6]

newf.write(mapping_file)
newf.write(input_dir)
newf.write(sample_name)
newf.write(output_dir)

#print "input dir " + input_dir
#print "output_dir" + output_dir

#open mapping file
f = open(mapping_file,"r")
print "Reading from  mapping file : " + mapping_file
sys.stdout.flush()
header = f.readline().split("\t")
#print header
sample_id_position = header.index("#SampleID")
group_position = header.index("Grouping")

subjects = set()

for line in f:
	splitted_line = line.split("\t")
	subjects.add(splitted_line[group_position])
	sampleId = splitted_line[sample_id_position]
	#print sampleId + "\n"
	all_sample_ids = all_sample_ids + sampleId + ","
	file1 = sample_name + "-" + barcode + sampleId[4:] + "_S" + sampleId[4:] + "_L001_R1_001.fastq.gz"
	file2 = sample_name + "-" + barcode + sampleId[4:] + "_S" + sampleId[4:] + "_L001_R2_001.fastq.gz"
	#print file1 +  "   " + file2
	subprocess.check_call("join_paired_ends.py -f " +  input_dir + "/" + file1 +" -r "+ input_dir + "/" + file2 + " -o " + output_dir,  shell=True)
	dst = "joined_"+  sampleId[4:] +".fastq"
	os.rename(output_dir + "/fastqjoin.join.fastq", output_dir + "/"+ dst)
	all_files = all_files + dst + ","
	newf.write(dst)	


#newf.write(subjects)
#newf.write(all_files)
#newf.write(all_sample_ids)

print "Joined R1 and R2 files for all samples can be found in " + output_dir
filenames = open("filenames","w+")
samples = open("samples.txt", "w+")
filenames.write(all_files[:-1])
samples.write(all_sample_ids[:-1])

filenames.close()
samples.close()
f.close()
newf.close()

all_sample_ids = all_sample_ids[:-1]
#print all_sample_ids
all_files = all_files[:-1]
os.chdir(output_dir)
pwd = os.getcwd()
print "Combining all fastq files into a single seqs.fna file."
subprocess.check_call("split_libraries_fastq.py -i " + all_files + " -o " + pwd + "/automated_sl_out/ -m " + mapping_file  + " --barcode_type not-barcoded   --sample_ids " + all_sample_ids, shell=True)

print "Created seqs.fna file in " + pwd + "/automated_sl_out folder."

if otu_method == "0":
	print "Creating OTU tables using QIIME:De Novo Method"
	sys.stdout.flush()	
	subprocess.check_call("pick_de_novo_otus.py -i " + pwd + "/automated_sl_out/seqs.fna -o " + pwd + "/de_novo_uclust_otus/" , shell=True)
elif otu_method == "1":
	print "Creating OTU tables using QIIME:Open reference clustering. GreenGenes will be used as reference database."
	sys.stdout.flush()
	try:
		subprocess.check_call("pick_open_reference_otus.py -i " + pwd + "/automated_sl_out/seqs.fna -o " + pwd + "/open_ref_ucrc97/ -r "+ script_path + "/gg_13_5_otus/rep_set/97_otus.fasta", shell=True)
		print "Summarizing the biom tables." 
		sys.stdout.flush()
		subprocess.check_call("biom summarize-table -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -o" + pwd + "/open_ref_ucrc97/biom_summary.txt", shell=True)
		subprocess.check_call("summarize_taxa_through_plots.py -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -o " + pwd + "/open_ref_ucrc97/taxa_summary -m " + mapping_file, shell=True)
		print "Summary of taxonomy can be found in " + pwd + "/open_ref_ucrc97/taxa_summary"
		sys.stdout.flush()
		print "Generating Beta diversity pcoa plots."
		sys.stdout.flush()
		subprocess.check_call("beta_diversity_through_plots.py -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -o " + pwd + "/open_ref_ucrc97/Beta_diversity/ -t " + pwd + "/open_ref_ucrc97/rep_set.tre -m " + mapping_file, shell=True)
		print "Generating 2D plots for Beta diversity."
		sys.stdout.flush()
		subprocess.check_call("make_2d_plots.py -i " + pwd + "/open_ref_ucrc97/Beta_diversity/unweighted_unifrac_pc.txt -o " + pwd + "/open_ref_ucrc97/Beta_diversity/bdiv_2d_plot -m " + mapping_file, shell = True)
		print "Generated 2D plots for beta diversity in " + pwd + "/open_ref_ucrc97/Beta_diversity/bdiv_2d_plot"
		print "Calculating Alpha diversity."
		sys.stdout.flush()
		subprocess.check_call("multiple_rarefactions.py -i " + pwd + "/open_ref_ucrc97/otu_table_mc2_w_tax.biom -m 10 -x 140 -s 10 -n 2 -o " + pwd + "open_ref_ucrc97/Alpha_diversity/rarefied_otu_tables/", shell=True)
		subprocess.check_call("alpha_diversity.py -i " + pwd + "/open_ref_ucrc97/Alpha_diversity/rarefied_otu_tables/ -m chao1,PD_whole_tree -o "+ pwd + "open_ref_ucrc97/Alpha_diversity/adiv_chao1_pd/ -t "+ pwd + "/open_ref_ucrc97/rep_set.tre", shell=True)
		subprocess.check_call("collate_alpha.py -i " + pwd + "open_ref_ucrc97/Alpha_div/adiv_chao1_pd/ -o " + pwd + "open_ref_ucrc97/Alpha_div/collated_alpha/", shell=True)
		subprocess.check_call("compare_alpha_diversity.py -i " + pwd +"/open_ref_ucrc97/Alpha_div/collated_alpha/PD_whole_tree.txt -m " + mapping_file + " -c Grouping -o " + pwd + "/open_ref_ucrc97/Alpha_div/comparing_alpha_grouping", shell=True)
	except OSError as e:
		print("Execution failed:", e, sys.stderr)
		sys.stdout.flush()

elif otu_method == "2":
	print "Creating OTU tables using QIIME: Closed reference clustering. GreenGenes will be used as reference database."
	subprocess.check_call("pick_closed_reference_otus.py -i " + pwd + "/automated_sl_out/seqs.fna -o " + pwd + "/closed_ref_ucrc97/ -r "+ script_path + "/gg_13_5_otus/rep_set/97_otus.fasta -t " + script_path + "/gg_13_5_otus/taxonomy/97_otu_taxonomy.txt", shell=True)
	while subjects:
		subject = subjects.pop()
		subprocess.check_call("filter_samples_from_otu_table.py -i " + pwd + "/closed_ref_ucrc97/otu_table.biom -o " + pwd + "/closed_ref_ucrc97/" + subject + "/otu_table_"+ subject +"_only.biom -m " + mapping_file +" -s 'Grouping:" + subject + "'", shell=True)
		subprocess.check_call("biom summarize-table -i " + pwd + "/closed_ref_ucrc97/" + subject + "/otu_table_"+ subject +"_only.biom  -o " + pwd + "/closed_ref_ucrc97/" + subject + "/biom_summary.txt", shell=True)
		subprocess.check_call("summarize_taxa_through_plots.py -i " + pwd + "/closed_ref_ucrc97/" + subject + "/otu_table_"+ subject +"_only.biom -o " + pwd + "/closed_ref_ucrc97/" + subject + "/taxa_summary -m " + mapping_file, shell=True)
		print "Summary of taxonomy can be found in subject specific folders under " + pwd + "/closed_ref_ucrc97"

else:
	print "Please choose the valid method for OTU clustering."
	print "Exiting the process due to bad input."


#if __name__ == '__main__':
#   run_qiime()

